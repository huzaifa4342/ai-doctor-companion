import ChatInterface from "@/components/ChatInterface";

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24 bg-slate-50">
      <div className="z-10 max-w-5xl w-full items-center justify-between font-mono text-sm lg:flex mb-8">
        <h1 className="text-4xl font-bold text-blue-600 mx-auto">AI Doctor Companion</h1>
      </div>

      <div className="w-full max-w-4xl">
        <p className="text-center text-gray-600 mb-8">
          Describe your symptoms or upload a lab report for analysis.
        </p>
        <ChatInterface />
      </div>
    </main>
  );
}
